from django.apps import AppConfig


class CellcountConfig(AppConfig):
    name = 'cellcount'
