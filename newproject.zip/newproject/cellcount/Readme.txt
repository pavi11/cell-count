#predict.py consists of the segmentation and prediction logic
#load the models of the trained algo (using cell images). 
